export class UserSetting {
    constructor(dbConn, id = null, data = {}) {
        this._id = id;
        this._dbConn = dbConn;
        this._data = data; // store other fields dynamically
    }

    async init(id = null) {
        try {
            const currentPK = id ? id : this._id;
            if (!currentPK) throw new Error('Primary Key is not initialized.');
            if (!this._dbConn || this._dbConn.status !== true) throw new Error('DB Connection not established or module disabled');

            const result = await this._dbConn.fetch(
                `SELECT * FROM user_settings WHERE id = $1`,
                [currentPK]
            );
            if (!result?.data || result.data.length < 1) throw new Error('Record not found');

            this._id = currentPK;
            this._data = result.data[0];
        } catch (err) {
            console.error('Init failed', err);
        }
    }

    async getData() {
        if (!this._id) throw new Error('Data not initialized');
        return { id: this._id, ...this._data };
    }

    async create(data) {
        try {
            if (!this._dbConn || this._dbConn.status !== true) throw new Error('DB Connection not established');
            // validate fields
            for (const key in data) {
                if (!["user_id", "profile_visibility", "show_online_status", "show_last_seen", "email_notifications", "push_notifications", "sms_notifications", "notification_likes", "notification_comments", "notification_follows", "notification_mentions", "notification_messages", "auto_play_videos", "show_sensitive_content", "created_at", "updated_at"].includes(key)) throw new Error(`Invalid column field "${key}"`);
            }
            const cols = Object.keys(data);
            const values = Object.values(data);
            const placeholders = cols.map((_, i) => f"${i+1}").join(", ");
            const query = `INSERT INTO user_settings(${cols.join(", ")}) VALUES(${placeholders}) RETURNING *;`;
            const result = await this._dbConn.client.query(query, values);
            return result.rows[0];
        } catch (err) {
            console.error('Create failed', err);
            return null;
        }
    }

    async update(data) {
        try {
            if (!this._dbConn || this._dbConn.status !== true) throw new Error('DB Connection not established');
            if (!this._id) throw new Error('Missing primary key');
            for (const key in data) {
                if (!["user_id", "profile_visibility", "show_online_status", "show_last_seen", "email_notifications", "push_notifications", "sms_notifications", "notification_likes", "notification_comments", "notification_follows", "notification_mentions", "notification_messages", "auto_play_videos", "show_sensitive_content", "created_at", "updated_at"].includes(key)) throw new Error(`Invalid column field "${key}"`);
            }
            const cols = Object.keys(data);
            const values = Object.values(data);
            if (!cols.length) throw new Error('No valid fields to update');
            let setClause = cols.map((c, i) => `\${c} = $${i+1}`).join(", ");
            const query = `UPDATE user_settings SET ${setClause} WHERE id = $${cols.length + 1} RETURNING *;`;
            const result = await this._dbConn.client.query(query, [...values, this._id]);
            return result.rows[0];
        } catch (err) {
            console.error('Update failed', err);
            return null;
        }
    }

    async delete() {
        try {
            if (!this._dbConn || this._dbConn.status !== true) throw new Error('DB Connection not established');
            if (!this._id) throw new Error('Missing primary key');
            const result = await this._dbConn.client.query(
                `DELETE FROM user_settings WHERE id = $1 RETURNING *;`,
                [this._id]
            );
            return !!result.rows[0];
        } catch (err) {
            console.error('Delete failed', err);
            return false;
        }
    }
}

export class UserSettingList {
    constructor(dbConn) {
        this.dbConn = dbConn;
        this.data = [];
    }
    async init() {
        try {
            if (!this.dbConn || this.dbConn.status !== true) throw new Error('DB Connection not established');
            const result = await this.dbConn.fetch('SELECT * FROM user_settings');
            this.data = result.data.map(row => new UserSetting(this.dbConn, row.id, row));
        } catch (err) {
            console.error('List init failed', err);
        }
    }
    async getAllData() {
        return Promise.all(this.data.map(d => d.getData()));
    }
    async getDataByPK(pk) {
        return this.data.find(d => d._id === pk) || null;
    }
}
